import React from "react";
import "./App.css";
import Routing from "./routes/Routes";

function App() {
     return (
          <>
               <Routing />
          </>
     );
}

export default App;
