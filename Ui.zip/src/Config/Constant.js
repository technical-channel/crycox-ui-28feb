export const RPC =
  "https://goerli.infura.io/v3/9c48d1f781404552b1a017d597f6bee1";
