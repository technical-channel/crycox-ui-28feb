export const EscrowAddress = "0x1448BA4B15B0b13Cf234f57e356056bD076325ac"; // escrowcontractaddress here
export const USDTECR20Token = "0x2df7A21742ebb08ef1496eCd0CfA6AdBd585B38c"; //USDTECR20n here..
export const USDTBEP20Token = "0x375cFeEc6Bf5682F60F4686156E4e8f71D889a8D"; //USDTBEP20Token here..
export const DOGECoinToken = "0x61da5E810FC118bA07190bCBaA49A8D6A4f39b52"; //DOGECoin here..
export const SHIBAINUToken = "0xF7135228d513d11610d2D2C3AFB0083632573200"; //SHIBAINUToken here..
export const BTCBitcoinToken = "0xb012F9f57E7d0490D1D8F3f26Bd62A8D44F3A31E"; //BTCBitcoinToken here..
export const BUSDBep20 = "0xe1f418243082fB6fd7DDeBbe103ab2A95e3De90E"; //BUSDBep20 here..
